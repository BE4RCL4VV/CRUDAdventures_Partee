﻿USE [AdventureWorksLT2019]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[Customers_CRUD]
	@Action			VARCHAR(10),
	@CustomerID		INT = NULL,
	@AddressID		INT = NULL,
	@FirstName		NVARCHAR(50) = NULL,
	@LastName		NVARCHAR(50) = NULL,
	@CompanyName	NVARCHAR(128) = NULL,
	@EmailAddress	NVARCHAR(50) = NULL,
	@Phone			NVARCHAR(25) = NULL,
	@AddressLine1	NVARCHAR(60) = NULL,
	@AddressLine2	NVARCHAR(60) = NULL,
	@City			NVARCHAR(30) = NULL,
	@StateProvince	NVARCHAR(50) = NULL,
	@CountryRegion	NVARCHAR(50) = NULL,
	@PostalCode		NVARCHAR(15) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	SET @Action = UPPER(@Action)

    IF @Action = 'SELECT'
	BEGIN
		SELECT FirstName, LastName, CompanyName, EmailAddress, Phone, AddressLine1, AddressLine2, City, StateProvince, CountryRegion, PostalCode, CustomerID, AddressId
		FROM [SalesLT].[vGetCustomers]
	END

    IF @Action = 'INSERT'
	BEGIN
		INSERT INTO [SalesLT].[Customer]  (FirstName, LastName, CompanyName, EmailAddress, Phone) 
		VALUES (@FirstName, @LastName, @CompanyName, @EmailAddress, @Phone)

		INSERT INTO [SalesLT].[Address] (AddressLine1, AddressLine2, City, StateProvince, CountryRegion, PostalCode)
		VALUES (@AddressLine1, @AddressLine2, @City, @StateProvince, @CountryRegion, @PostalCode)
	END

    IF @Action = 'UPDATE'
	BEGIN
		UPDATE [SalesLT].[Customer]
		SET FirstName = @FirstName, LastName = @LastName, CompanyName = @CompanyName, EmailAddress = @EmailAddress, Phone = @Phone
		WHERE CustomerID = @CustomerID

		UPDATE [SalesLT].[Address]
		SET AddressLine1 = @AddressLine1, AddressLine2 = @AddressLine2, City = @City, StateProvince = @StateProvince, CountryRegion = @CountryRegion, PostalCode = @PostalCode
		WHERE AddressId = @AddressId
	END

    IF @Action = 'DELETE'
	BEGIN
		DELETE FROM [SalesLT].[Customer]
		WHERE CustomerID = @CustomerID
	END
END
GO

CREATE VIEW SalesLT.vGetCustomers
AS

SELECT SalesLT.Customer.Title, SalesLT.Customer.FirstName, SalesLT.Customer.LastName, SalesLT.Customer.Suffix, SalesLT.Customer.CompanyName, SalesLT.Customer.EmailAddress, SalesLT.Customer.Phone, 
                  SalesLT.Address.AddressLine1, SalesLT.Address.AddressLine2, SalesLT.Address.City, SalesLT.Address.StateProvince, SalesLT.Address.CountryRegion, SalesLT.Address.PostalCode, SalesLT.Customer.CustomerID, 
                  SalesLT.CustomerAddress.AddressID
FROM     SalesLT.Customer INNER JOIN
                  SalesLT.CustomerAddress ON SalesLT.Customer.CustomerID = SalesLT.CustomerAddress.CustomerID INNER JOIN
                  SalesLT.Address ON SalesLT.CustomerAddress.AddressID = SalesLT.Address.AddressID
GO


CREATE VIEW ProductView
AS

SELECT SalesLT.Product.Name, SalesLT.Product.ProductNumber, SalesLT.Product.Color, SalesLT.Product.StandardCost, SalesLT.Product.ListPrice, SalesLT.Product.Size, SalesLT.Product.Weight, SalesLT.Product.SellStartDate, 
                  SalesLT.Product.SellEndDate, SalesLT.ProductCategory.Name AS CategoryName, SalesLT.ProductDescription.Description
FROM     SalesLT.Product INNER JOIN
                  SalesLT.ProductModel ON SalesLT.Product.ProductModelID = SalesLT.ProductModel.ProductModelID INNER JOIN
                  SalesLT.ProductCategory ON SalesLT.Product.ProductCategoryID = SalesLT.ProductCategory.ProductCategoryID INNER JOIN
                  SalesLT.ProductModelProductDescription ON SalesLT.ProductModel.ProductModelID = SalesLT.ProductModelProductDescription.ProductModelID INNER JOIN
                  SalesLT.ProductDescription ON SalesLT.ProductModelProductDescription.ProductDescriptionID = SalesLT.ProductDescription.ProductDescriptionID
GO

CREATE OR ALTER PROC [dbo].[ShowProducts]
AS
BEGIN

SELECT [Name], ProductNumber, Color, StandardCost, ListPrice,
	   Size, Weight, SellStartDate, SellEndDate, CategoryName, Description
FROM   [dbo].[ProductView]
END
GO
