﻿USE [AdventureWorksLT2019]
GO

DROP PROCEDURE Customers_CRUD
GO

DROP VIEW SalesLT.vGetCustomers
GO

DROP VIEW ProductView
GO

DROP PROCEDURE ShowProducts
GO