﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Configuration;

namespace Partee_Adventure
{
    public partial class Customer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
                BindRepeater();
        }

        protected void BindRepeater()
        {
            using (SqlConnection conn = new SqlConnection(dbAccess.getConnection()))
            {
                SqlCommand cmd = new SqlCommand("Customers_CRUD");
                cmd.Parameters.AddWithValue("@Action", "SELECT");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                RtrCustomer.DataSource = dr;
                RtrCustomer.DataBind();

            }
        }
        protected void Insert(object sender, EventArgs e)
        {

            string Firstname = txtFirstName.Text;
            string Lastname = txtLastName.Text;
            string CompanyName = txtCompanyName.Text;
            string EmailAddress = txtEmailAddress.Text;
            string Phone = txtPhone.Text;
            string AddressLine1 = txtAddressLine1.Text;
            string AddressLine2 = txtAddressLine2.Text;
            string City = txtCity.Text;
            string StateProvince = txtStateProvince.Text;
            string CountryRegion = txtCountryRegion.Text;
            string PostalCode = txtPostalCode.Text;
            using (SqlConnection conn = new SqlConnection(dbAccess.getConnection()))
            {
                using (SqlCommand cmd = new SqlCommand("Customers_CRUD", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "INSERT");                   
                    cmd.Parameters.AddWithValue("@FirstName", Firstname);
                    cmd.Parameters.AddWithValue("@LastName", Lastname);
                    cmd.Parameters.AddWithValue("@CompanyName", CompanyName);
                    cmd.Parameters.AddWithValue("@EmailAddress", EmailAddress);
                    cmd.Parameters.AddWithValue("@Phone", Phone);
                    cmd.Parameters.AddWithValue("@AddressLine1", AddressLine1);
                    cmd.Parameters.AddWithValue("@AddressLine2", AddressLine2);
                    cmd.Parameters.AddWithValue("@City", City);
                    cmd.Parameters.AddWithValue("@StateProvince", StateProvince);
                    cmd.Parameters.AddWithValue("@CountryRegion", CountryRegion);
                    cmd.Parameters.AddWithValue("@PostalCode", PostalCode);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            this.BindRepeater();
        }

        protected void OnEdit(object sender, EventArgs e)
        {
            //Find the reference of the Repeater Item.
            RepeaterItem item = (sender as LinkButton).Parent as RepeaterItem;
            this.ToggleElements(item, true);
        }

        private void ToggleElements(RepeaterItem item, bool isEdit)
        {
            //Toggle Buttons.
            item.FindControl("lnkEdit").Visible = !isEdit;
            item.FindControl("lnkUpdate").Visible = isEdit;
            item.FindControl("lnkCancel").Visible = isEdit;
            item.FindControl("lnkDelete").Visible = !isEdit;
            
            item.FindControl("lblFirstName").Visible = !isEdit;
            item.FindControl("lblLastName").Visible = !isEdit;
            item.FindControl("lblCompanyName").Visible = !isEdit;
            item.FindControl("lblEmailAddress").Visible = !isEdit;
            item.FindControl("lblPhone").Visible = !isEdit;
            item.FindControl("lblAddressLine1").Visible = !isEdit;
            item.FindControl("lblAddressLine2").Visible = !isEdit;
            item.FindControl("lblCity").Visible = !isEdit;
            item.FindControl("lblStateProvince").Visible = !isEdit;
            item.FindControl("lblCountryRegion").Visible = !isEdit;
            item.FindControl("lblPostalCode").Visible = !isEdit;

            item.FindControl("txtFirstName").Visible = isEdit;
            item.FindControl("txtLastName").Visible = isEdit;
            item.FindControl("txtCompanyName").Visible = isEdit;
            item.FindControl("txtEmailAddress").Visible = isEdit;
            item.FindControl("txtPhone").Visible = isEdit;
            item.FindControl("txtAddressLine1").Visible = isEdit;
            item.FindControl("txtAddressLine2").Visible = isEdit;
            item.FindControl("txtCity").Visible = isEdit;
            item.FindControl("txtStateProvince").Visible = isEdit;
            item.FindControl("txtCountryRegion").Visible = isEdit;
            item.FindControl("txtPostalCode").Visible = isEdit;
        }

        protected void OnCancel(object sender, EventArgs e)
        {
            RepeaterItem item = (sender as LinkButton).Parent as RepeaterItem;
            this.ToggleElements(item, false);
        }

        protected void OnUpdate(object sender, EventArgs e)
        {
            RepeaterItem item = (sender as LinkButton).Parent as RepeaterItem;
            int customerId = int.Parse((item.FindControl("lblCustomerID") as Label).Text);
            int addressId = int.Parse((item.FindControl("lblAddressId") as Label).Text);
            string FirstName = (item.FindControl("txtFirstName") as TextBox).Text.Trim();
            string LastName = (item.FindControl("txtLastName") as TextBox).Text.Trim();
            string CompanyName = (item.FindControl("txtCompanyName") as TextBox).Text.Trim();
            string EmailAddress = (item.FindControl("txtEmailAddress") as TextBox).Text.Trim();
            string Phone = (item.FindControl("txtPhone") as TextBox).Text.Trim();
            string AddressLine1 = (item.FindControl("txtAddressLine1") as TextBox).Text.Trim();
            string AddressLine2 = (item.FindControl("txtAddressLine2") as TextBox).Text.Trim();
            string City = (item.FindControl("txtCity") as TextBox).Text.Trim();
            string StateProvince = (item.FindControl("txtStateProvince") as TextBox).Text.Trim();
            string CountryRegion = (item.FindControl("txtCountryRegion") as TextBox).Text.Trim();
            string PostalCode = (item.FindControl("txtPostalCode") as TextBox).Text.Trim();

            using (SqlConnection conn = new SqlConnection(dbAccess.getConnection()))
            {
                using (SqlCommand cmd = new SqlCommand("Customers_CRUD"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "UPDATE");
                    cmd.Parameters.AddWithValue("@CustomerID", customerId);
                    cmd.Parameters.AddWithValue("@AddressId", addressId);
                    cmd.Parameters.AddWithValue("@FirstName", FirstName);
                    cmd.Parameters.AddWithValue("@LastName", LastName);
                    cmd.Parameters.AddWithValue("@CompanyName", CompanyName);
                    cmd.Parameters.AddWithValue("@EmailAddress", EmailAddress);
                    cmd.Parameters.AddWithValue("@Phone", Phone);
                    cmd.Parameters.AddWithValue("@AddressLine1", AddressLine1);
                    cmd.Parameters.AddWithValue("@AddressLine2", AddressLine2);
                    cmd.Parameters.AddWithValue("@City", City);
                    cmd.Parameters.AddWithValue("@StateProvince", StateProvince);
                    cmd.Parameters.AddWithValue("@CountryRegion", CountryRegion);
                    cmd.Parameters.AddWithValue("@PostalCode", PostalCode);
                    cmd.Connection = conn;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            BindRepeater();
        }

        protected void OnDelete(object sender, EventArgs e)
        {
            RepeaterItem item = (sender as LinkButton).Parent as RepeaterItem;
            int customerId = int.Parse((item.FindControl("lblCustomerID") as Label).Text);
            int addressId = int.Parse((item.FindControl("lblAddressId") as Label).Text);

            string conn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            using (SqlConnection sqlConn = new SqlConnection(conn))
            {
                using (SqlCommand cmd = new SqlCommand("Customers_CRUD"))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Action", "DELETE");
                    cmd.Parameters.AddWithValue("@CustomerID", customerId);
                    cmd.Connection = sqlConn;
                    sqlConn.Open();
                    cmd.ExecuteNonQuery();
                    sqlConn.Close();
                }
            }
            this.BindRepeater();
        }

        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("DefaultPage.aspx");
        }

        protected void btnProducts_Click(object sender, EventArgs e)
        {
            Response.Redirect("Product.aspx");
        }
    }
}